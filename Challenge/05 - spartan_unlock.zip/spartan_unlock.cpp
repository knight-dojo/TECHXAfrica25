#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::string keyInput;
    std::string correctKey = "Missing Stings";  // Define your secret key here

    std::cout << "Enter the secret key to unlock the flag: ";
    std::getline(std::cin, keyInput);

    if (keyInput == correctKey) {
        // ASCII codes for: plaintext_revealed
        std::string asciiInput = "112 108 97 105 110 116 101 120 116 95 114 101 118 101 97 108 101 100";
        std::stringstream ss(asciiInput);
        int asciiCode;
        std::string plainText;

        while (ss >> asciiCode) {
            plainText += static_cast<char>(asciiCode);
        }

        std::cout << "flag{" << plainText << "}" << std::endl;
    } else {
        std::cout << "Incorrect key. Access denied." << std::endl;
    }

    return 0;
}
